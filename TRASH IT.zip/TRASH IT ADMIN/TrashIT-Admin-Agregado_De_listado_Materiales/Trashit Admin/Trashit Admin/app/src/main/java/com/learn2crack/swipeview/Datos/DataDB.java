package com.learn2crack.swipeview.Datos;

public class DataDB {

    public static String host="sql10.freesqldatabase.com";
    public static String port="3306";
    public static String nameBD="sql10450491";
    public static String user="sql10450491";
    public static String pass="H6h5N8GTXX";

    //Información para la conexion
    public static String urlMySQL = "jdbc:mysql://" + host + ":" + port + "/"+nameBD;
    public static String driver = "com.mysql.jdbc.Driver";
}
